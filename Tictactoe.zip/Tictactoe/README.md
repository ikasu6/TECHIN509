if mode 1:
create two-person objects and do  game moves

if mode 2:
create a person object and  a robot object  and do game moves

if mode 3:
create 2 bot objects and game moves


actions of a robot object:
(i)have name
(ii)have player position
(iii)have 'X' or 'O' symbol
(iv)pick a random integer on the board 

actions of a person
(i)have name
(ii)have player position
(iii)have 'X' or 'O' symbol
(iv)enter a position on the board

Game actions:
(i)position entered  by a bot or person should be displayed on the board
(ii)check the conditions to get a winner no winner
